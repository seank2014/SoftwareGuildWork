/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.dao;

import com.sg.flooring.dto.Order;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author seanking
 */
public class OrderDAOStubImpl implements OrderDAO{
    
    Order onlyOrder;
    List<Order>orderList = new ArrayList<>();
    LocalDate ld = LocalDate.now();
    OrderDAO dao;
    
    public OrderDAOStubImpl(){
        onlyOrder = new Order(ld);
        onlyOrder.setOrderNumber(1);
        onlyOrder.setCustomerName("weis");
        onlyOrder.setState("OH");
        
        orderList.add(onlyOrder);
    }

    @Override
    public Order createOrder(LocalDate date, Order order) 
    throws FlooringPersistenceException{
        if(date.equals(onlyOrder.getOrderDate())){
            return onlyOrder;
        }else{
            return null;
        }
    }

    @Override
    public Order getOrderByDate(LocalDate date, int id) { 
        if(date.equals(onlyOrder.getOrderDate()) && id == onlyOrder.getOrderNumber()){
            return onlyOrder;
        }else{
            return null;
        }
    }

    @Override
    public List<Order> getAllOrders() {
        return orderList;
    }

    @Override
    public void updateOrder(LocalDate date, int id) throws FlooringPersistenceException {
       // Order updatedOrder = dao.getOrderByDate(date, id);
    }

    @Override
    public Order deleteOrder(LocalDate date, int id) {
        if(date.equals(onlyOrder.getOrderDate()) && id == onlyOrder.getOrderNumber()){
            return onlyOrder;
        }else{
            return null;
        }


    }

   

    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.controller;

import com.sg.flooring.dao.FlooringPersistenceException;
import com.sg.flooring.dto.Order;
import com.sg.flooring.service.InvalidDataException;
import com.sg.flooring.service.OrderDoesNotExistException;
import com.sg.flooring.service.ServiceLayer;
import com.sg.flooring.ui.View;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 *
 * @author seanking
 */
public class FlooringController {

    private ServiceLayer service;
    private View view;

    public FlooringController(ServiceLayer service, View view) {
        this.service = service;
        this.view = view;

    }

    public void run() throws FlooringPersistenceException {
        boolean keepGoing = true;
        int menuSelection = 0;
        String pickMode = "";
        try {
            while (keepGoing) {
                pickMode = getPickMode();
                menuSelection = getMenuSelection();
                switch (menuSelection) {
                    case 1:
                        displayOrders();
                        break;
                    case 2:
                        addOrder();
                        break;
                    case 3:
                        editOrder();
                        break;
                    case 4:
                        removeOrder();
                        break;
                    case 5:
                        saveCurrentWork();
                        break;
                    case 6:
                        keepGoing = false;
                        break;
                    default:
                        unknownCommand();
                }
            }
            exitMessage();
        } catch (Exception e) {
            view.displayErrorMessage(e.getMessage());
        }

    }
    
    private String getPickMode(){
        return view.printPickMode();
    }

    private int getMenuSelection() {
        return view.printMenuANdGetSelection();
    }

    private void displayOrders() throws FlooringPersistenceException, OrderDoesNotExistException {
        view.displayAllOrdersBanner();
        List<Order> orderList = service.getAllOrders();
        view.displayOrderList(orderList);
    }

    private void addOrder() throws FlooringPersistenceException, InvalidDataException {
        view.displayOrderCreateBanner();
        Order newOrder = view.getNewOrderInfo();
        service.createOrder(newOrder);
        view.displayOrderCreatedSuccessBanner();

    }

    private void editOrder() throws FlooringPersistenceException, InvalidDataException {
        view.displayOrderEditedBanner();
        int id = view.getOrderNumber();
        Order editedOrder = service.findOrder(id);
        if (editedOrder != null) {
            Order orderTwo = view.getNewOrderInfo();
            if (id != orderTwo.getOrderNumber()) {
                service.deleteOrder(LocalDate.parse("", DateTimeFormatter.ISO_DATE));
                id = orderTwo.getOrderNumber();
                service.createOrder(orderTwo);
            } else {
               // Order orderOne = service.updateOrder();
            }
            view.displayEditSuccesfulBanner();
        } else {
            System.out.println("Entry not found");
        }

    }

    private void removeOrder() throws FlooringPersistenceException {
        view.displayDeleteOrderBanner();
        int id = view.getOrderNumber();
        service.deleteOrder(LocalDate.parse(""));
        view.displayOrderDeletedSuccessfulBanner();
    }

    private void saveCurrentWork() {

    }

    private void unknownCommand() {
        view.displayUnknownCommandBanner();
    }
    

    public void exitMessage() {
        view.displayExitBanner();

    }

}

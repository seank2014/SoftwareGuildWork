/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.service;

import com.sg.flooring.dao.FlooringAuditDao;
import com.sg.flooring.dao.FlooringPersistenceException;
import com.sg.flooring.dao.OrderDAO;
import com.sg.flooring.dao.ProductDAO;
import com.sg.flooring.dao.TaxDAO;
import com.sg.flooring.dto.Order;
import com.sg.flooring.dto.Tax;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author seanking
 */
public class ServiceLayerImpl implements ServiceLayer {

    private FlooringAuditDao auditDao;
    OrderDAO orderPDao;
    //Do I need two order DAOs? If so, why?
    ProductDAO productDao;
    TaxDAO taxDao;

    public ServiceLayerImpl(FlooringAuditDao auditDao, OrderDAO orderPDAO, ProductDAO prodcutDao, TaxDAO taxDao) {
        this.orderPDao = orderPDao;
        this.auditDao = auditDao;
        this.productDao = productDao;
        this.taxDao = taxDao;
    }

    @Override
    public void createOrder(Order order)
           throws FlooringPersistenceException, InvalidDataException {
        if (orderPDao.getOrderByDate(LocalDate.now(), order.getOrderNumber()) != null) {
            throw new InvalidDataException("Error: Could not create order. Order Number "
                    + order.getOrderNumber()
                    + " already exists");
        }
        
        validateOrderInfo(order);
        orderPDao.createOrder(order.getOrderDate(), order);
        auditDao.writeAuditEntry("Order " + order.getOrderNumber() + " was created on " + order.getOrderDate());

    }

    @Override
    public List<Order> getAllOrders() throws FlooringPersistenceException {
        return orderPDao.getAllOrders();
    }

    
     private BigDecimal calcualteTotal(){
         /*6.75/100 = 0.0675
            (materialCost + laborCost) * 0.0675 = totalTaxToApply*/
         BigDecimal total = new BigDecimal ("");
         return total;
         
     }

    @Override
    public Order findOrder(int id) throws FlooringPersistenceException {
        return orderPDao.getOrderByDate(LocalDate.parse(""), id);
    }

    @Override
    public void saveCurrentWork(Order order) throws FlooringPersistenceException {
        
    }

    @Override
    public void updateOrder() {

    }

    @Override
    public Order deleteOrder(LocalDate date) throws FlooringPersistenceException {
        auditDao.writeAuditEntry("Order made on " + date + " has been removed");
        return orderPDao.deleteOrder(date, 0);
    }

    @Override
    public Tax applyTaxes(BigDecimal tax) {
        
        
      return taxDao.getTaxByState(("tax"));
    }

    private void validateOrderInfo(Order order) throws
            InvalidDataException {
        if (order.getCustomerName() == null
                || order.getCustomerName().trim().length() == 0
                || order.getState() == null
                || order.getState().trim().length() == 0
                || order.getProductType() == null
                || order.getProductType().trim().length() == 0
                || order.getArea() == null
                || order.getArea().toString().trim().length() == 0) {

            throw new InvalidDataException(
                    "ERROR: All fields [Company name, State, Product and Amount of material]");

        }
    }

}

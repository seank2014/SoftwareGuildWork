/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.service;
import com.sg.flooring.dao.FlooringPersistenceException;
import com.sg.flooring.dto.Order;
import com.sg.flooring.dto.Tax;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author seanking
 */
public interface ServiceLayer {
    
    public void createOrder(Order order) throws FlooringPersistenceException, InvalidDataException;
    List<Order>getAllOrders()throws FlooringPersistenceException, OrderDoesNotExistException;
    public Order findOrder(int id)throws FlooringPersistenceException;
    public void saveCurrentWork(Order order)throws FlooringPersistenceException;
    public void updateOrder()throws FlooringPersistenceException;
    public Order deleteOrder(LocalDate date)throws FlooringPersistenceException;
    public Tax applyTaxes(BigDecimal tax)throws FlooringPersistenceException;
    
    
    
}

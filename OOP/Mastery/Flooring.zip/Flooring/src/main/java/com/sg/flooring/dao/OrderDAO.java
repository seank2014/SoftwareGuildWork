/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.dao;

import com.sg.flooring.dto.Order;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author seanking
 */
public interface OrderDAO {
//need to clarify between order prod and training
    Order createOrder(LocalDate date, Order order)
                        throws FlooringPersistenceException;

    Order getOrderByDate(LocalDate date, int id)
            throws FlooringPersistenceException;

    List<Order> getAllOrders()
            throws FlooringPersistenceException;

    void updateOrder(LocalDate date, int id)
            throws FlooringPersistenceException;

    Order deleteOrder(LocalDate date, int id)
            throws FlooringPersistenceException;

}

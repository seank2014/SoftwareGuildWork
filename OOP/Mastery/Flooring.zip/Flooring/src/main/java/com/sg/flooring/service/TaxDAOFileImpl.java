/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.service;

import com.sg.flooring.dao.TaxDAO;
import com.sg.flooring.dto.Tax;

/**
 *
 * @author seanking
 */
public class TaxDAOFileImpl implements TaxDAO {

    public TaxDAOFileImpl() {
    }

    @Override
    public Tax getTaxByState(String stateName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

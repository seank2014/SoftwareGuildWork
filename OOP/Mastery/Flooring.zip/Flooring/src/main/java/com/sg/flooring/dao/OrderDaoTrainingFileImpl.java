/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.dao;

import com.sg.flooring.dto.Order;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author seanking
 */
public class OrderDaoTrainingFileImpl implements OrderDAO{
    public Map< Integer, Order> orders = new HashMap<>();
    Order order = new Order(LocalDate.now());
    public static final String ORDER_FILE = "Orders_" + LocalDate.now() + ".txt";
    public static final String DELIMITER = ",";


   @Override
    public Order createOrder(LocalDate date, Order order) {
        orders.put(order.getOrderNumber(), order);
        return order;
        
    }

    @Override
    public Order getOrderByDate(LocalDate date, int id) {
        return orders.get(id);
    }

    @Override
    public List<Order> getAllOrders() {
        return new ArrayList<>(orders.values());//returns order objects
    }

    @Override
    public void updateOrder(LocalDate date, int id) {

    }

    @Override
    public Order deleteOrder(LocalDate date, int id) {
        Order removedOrder = orders.remove(id);
        return removedOrder;
    }
    
      private void loadOrder() throws FlooringPersistenceException {
        Scanner scanner;

        try {
            scanner = new Scanner(
                    new BufferedReader(
                            new FileReader(ORDER_FILE)));
        } catch (FileNotFoundException e) {
            throw new FlooringPersistenceException(
                    "-_- Could not load library data into memory.", e);
        }
        String currentLine;
        String[] currentTokens;
        while (scanner.hasNextLine()) {
            currentLine = scanner.nextLine();
            currentTokens = currentLine.split(DELIMITER);
            Order currentOrder = new Order(LocalDate.parse(currentTokens[0]));
            currentOrder.setOrderNumber(Integer.parseInt(currentTokens[1]));
            currentOrder.setCustomerName((currentTokens[2]));
            currentOrder.setState((currentTokens[3]));
            currentOrder.setTaxRate(new BigDecimal(currentTokens[4]));
            currentOrder.setProductType((currentTokens[5]));
            currentOrder.setArea(new BigDecimal(currentTokens[6]));
            currentOrder.setPerSquareFoot(new BigDecimal(currentTokens[7]));
            currentOrder.setLaborCost(new BigDecimal(currentTokens[8]));
            currentOrder.setMaterialCost(new BigDecimal(currentTokens[9]));
            currentOrder.setTotal(new BigDecimal(currentTokens[12]));     
        }
        
        scanner.close();
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.dao;

import com.sg.flooring.dto.Order;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author seanking
 */
public class OrderDAOProdFileImpl implements OrderDAO {

    public Map< Integer, Order> orders = new HashMap<>();
    Order order = new Order(LocalDate.now());
    public static final String ORDER_FILE = "Orders_" + LocalDate.now().format(DateTimeFormatter.ofPattern("MMddYYYY")) + ".txt";
    public static final String DELIMITER = ",";

    @Override
    public Order createOrder(LocalDate date, Order order) throws FlooringPersistenceException {
        //get maximum order Id to assign to order
        orders.put(order.getOrderNumber(), order);
        writeOrder();
        return order;

    }

    @Override
    public Order getOrderByDate(LocalDate date, int id) {
        return orders.get(id);
    }

    @Override
    public List<Order> getAllOrders() {
        return new ArrayList<>(orders.values());//returns order objects
    }

    @Override
    public void updateOrder(LocalDate date, int id/*need order as third parameter*/) {

    }

    @Override
    public Order deleteOrder(LocalDate date, int id) {
        Order removedOrder = orders.remove(id);
        return removedOrder;
    }

    private void loadOrder() throws FlooringPersistenceException {
        Scanner scanner;

        try {
            scanner = new Scanner(
                    new BufferedReader(
                            new FileReader(ORDER_FILE)));
        } catch (FileNotFoundException e) {
            throw new FlooringPersistenceException(
                    "-_- Could not load library data into memory.", e);
        }
        String currentLine;
        String[] currentTokens;
        while (scanner.hasNextLine()) {
            currentLine = scanner.nextLine();
            currentTokens = currentLine.split(DELIMITER);
            Order currentOrder = new Order(LocalDate.parse(currentTokens[0]));
            currentOrder.setOrderNumber(Integer.parseInt(currentTokens[1]));
            currentOrder.setCustomerName(currentTokens[2]);
            currentOrder.setState((currentTokens[3]));
            currentOrder.setTaxRate(new BigDecimal(currentTokens[4]));
            currentOrder.setProductType((currentTokens[5]));
            currentOrder.setArea(new BigDecimal(currentTokens[6]));
            currentOrder.setPerSquareFoot(new BigDecimal(currentTokens[7]));
            currentOrder.setLaborCost(new BigDecimal(currentTokens[8]));
            currentOrder.setMaterialCost(new BigDecimal(currentTokens[9]));
            currentOrder.setTotal(new BigDecimal(currentTokens[12]));
            //Make another class called "Order mapper" method toOrder(){ returns currentOrder(that information was parsed into)}
            //test will show if order is returned and if it has what I expect to be there
            //line 79 - 90 goes in class then, call that method here
        }
        scanner.close();
    }

    public void writeOrder() throws FlooringPersistenceException {

        PrintWriter out;

        try {
            out = new PrintWriter(new FileWriter(ORDER_FILE));
        } catch (Exception e) {
            throw new FlooringPersistenceException(
                    "Could not save student data.", e);
        }

        List<Order> orderList = this.getAllOrders();
        for (Order currentOrder : orderList) {
            // write the Student object to the file
            out.println(currentOrder.getOrderDate() + DELIMITER
                    + currentOrder.getOrderNumber() + DELIMITER
                    + currentOrder.getCustomerName() + DELIMITER
                    + currentOrder.getState() + DELIMITER
                    + currentOrder.getTaxRate() + DELIMITER
                    + currentOrder.getProductType() + DELIMITER
                    + currentOrder.getArea() + DELIMITER
                    + currentOrder.getPerSquareFoot() + DELIMITER
                    + currentOrder.getLaborCost() + DELIMITER
                    + currentOrder.getMaterialCost() + DELIMITER
                    + currentOrder.getTotal() 
                    //everything inside print line put in mapper class in another method
                    //also create test file for Mapper
                
            );
            // force PrintWriter to write line to the file
            out.flush();
        }
        //Clean up
        out.close();
    }

}

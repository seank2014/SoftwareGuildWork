/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.dao;

import com.sg.flooring.dto.Product;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author seanking
 */
public class ProductDAOTest {
    
    /* private ProductDAO dao = new ProductDAOFileImpl();*/
        
    
    public ProductDAOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {   
        }
    
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getProductByName method, of class ProductDAO.
     */
    @Test
    public void testGetProductByName() {
    }

    /**
     * Test of getAllProducts method, of class ProductDAO.
     */
    @Test
    public void testGetAllProducts() throws FlooringPersistenceException {
      /*  //Arrange
     Product product1 = new Product("Carpet");
        product1.setCostPerSquareFoot(new BigDecimal("2.25"));
        product1.setLaborCostPerSquareFoot(new BigDecimal("2.10"));
        dao.getProductByProductType(product1.getProductType());
        
       
        //Act
        Product product2 = new Product("Laminate");
        product2.setCostPerSquareFoot(new BigDecimal("1.75"));
        product2.setLaborCostPerSquareFoot(new BigDecimal("2.10"));
        dao.getProductByProductType(product2.getProductType());

      
      
        //Assert
        assertEquals(2, dao.getAllProducts().size());
        
        */
                
    }

   
}

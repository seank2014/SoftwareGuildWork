/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.flooring.dao;

import com.sg.flooring.dto.Order;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author seanking
 */
public class OrderDAOTest {

    private OrderDAO tDao = new OrderDAOProdFileImpl();

    public OrderDAOTest() throws Exception {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    /**
     *
     * @throws Exception
     */
    @Before
    public void setUp() throws Exception {

        List<Order> orderList = tDao.getAllOrders();
        for (Order order : orderList) {
            tDao.deleteOrder(order.getOrderDate(), order.getOrderNumber());

        }

    }

    @After
    public void tearDown() {
    }

    /**
     * Test of createOrder method, of class OrderTrainingDAO.
     * @throws java.lang.Exception
     */
    @Test
    public void testGetCreateOrder() throws Exception {

        //Arrange 
        Order order = new Order(LocalDate.now());
        order.setOrderNumber(1);
        order.setCustomerName("weis");
        tDao.createOrder(order.getOrderDate(), order);
        
        //Act
        Order fromDao = tDao.getOrderByDate(LocalDate.now(), 1);

        //Assert
        assertEquals(order, fromDao);

    }


    /**
     * Test of getAllOrders method, of class OrderTrainingDAO.
     */
    @Test
    public void testGetAllOrders() throws Exception{
        //Arrange 
        Order order1 = new Order(LocalDate.now());
        order1.setOrderNumber(1);
        order1.setCustomerName("Tom");
        tDao.createOrder(order1.getOrderDate(), order1);
        tDao.getOrderByDate(order1.getOrderDate(), 1);
        
        //Act 
        Order order2 = new Order(LocalDate.now());
        order2.setOrderNumber(2);
        order2.setCustomerName("Chase");
        tDao.createOrder(order2.getOrderDate(), order2);
        tDao.getOrderByDate(order2.getOrderDate(), 2);
        //Assert
        assertEquals(2, tDao.getAllOrders().size());
    }

    /**
     * Test of updateOrder method, of class OrderTrainingDAO.
     */
    @Test
    public void testUpdateOrder() {
    }

    /**
     * Test of deleteOrder method, of class OrderTrainingDAO.
     */
    @Test
    public void testDeleteOrder() throws FlooringPersistenceException {
        //Arrange 
        Order order1 = new Order(LocalDate.now());
        order1.setOrderNumber(1);
        order1.setCustomerName("Tom");
        
        tDao.createOrder(order1.getOrderDate(), order1);
        
        Order order2 = new Order(LocalDate.now());
        order2.setOrderNumber(2);
        order2.setCustomerName("Chase");
        tDao.createOrder(order2.getOrderDate(), order2);
        
        //Act //Assert
        tDao.deleteOrder(order1.getOrderDate(), 1);
        assertEquals(1,tDao.getAllOrders().size());
        assertNull(tDao.getOrderByDate(order1.getOrderDate(), 0));
        
        tDao.deleteOrder(order2.getOrderDate(), 2);
        assertEquals(0, tDao.getAllOrders().size());
        assertNull(tDao.getOrderByDate(order2.getOrderDate(), 0));  
         
        
    }

}

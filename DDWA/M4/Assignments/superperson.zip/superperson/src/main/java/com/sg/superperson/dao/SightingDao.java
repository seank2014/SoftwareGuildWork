/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.superperson.dao;

import com.sg.superperson.dto.Sighting;
import java.util.List;

/**
 *
 * @author seanking
 */
public interface SightingDao {
    
    //create
    
    Sighting addSighting();
    
    //read
    
    Sighting getSighting();
    
    
    List<Sighting> getAllSightings(String date);
    
    //update
    
    Sighting changeSighting();
    
    //delete
    
    Sighting deleteSighting();
    
}

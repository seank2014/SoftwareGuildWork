package com.sg.superperson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperpersonApplication {

	public static void main(String[] args) {
//		SpringApplication.run(SuperpersonApplication.class, args);
	}

}

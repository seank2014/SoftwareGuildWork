/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.superperson.dao;

import com.sg.superperson.dto.Location;
import com.sg.superperson.dto.SuperPerson;
import java.util.List;

/**
 *
 * @author seanking
 */
public interface LocationDao {
    //Create
    Location createLocation(String name, Location location);
    
    //Read
    Location getLocation(String name);
    
    List<Location>getAllLocations(SuperPerson superson);
   
    
    //Update
    Location changeLocation(String name);
    
    //Delete
    Location deleteLocation(String name);
}

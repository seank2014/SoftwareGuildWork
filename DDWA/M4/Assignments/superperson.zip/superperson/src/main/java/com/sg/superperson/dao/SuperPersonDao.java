/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.superperson.dao;

import com.sg.superperson.dto.Location;
import com.sg.superperson.dto.Organization;
import com.sg.superperson.dto.SuperPerson;
import java.util.List;

/**
 *
 * @author seanking
 */
public interface SuperPersonDao {
    
//Create


SuperPerson addSuperPerson(String name);    
  

//Read

SuperPerson getSuperPerson(String name);

List<SuperPerson>getAllSupers();

List<Organization>getAllOrganizationOfMember(Organization organization);

List<Location>getAllLocationSighted(String name);

    
//Update

SuperPerson updateSuperPerson(String name);
    

//Delete

SuperPerson deleteSuperPerson(String name);
}

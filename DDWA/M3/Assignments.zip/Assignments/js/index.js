$(document).ready(function () {

    //wiring up " Add Dollar" button
    $(document).on('click', '#addDollar', function(){
        alert('dollars');
    })

     //wiring up " Add Quarter" button
    $(document).on('click', '#addQuarter', function(){
        alert('Quarters');
    })

     //wiring up " Add Dime" button
    $(document).on('click', '#addDime', function(){
        alert('Dime');
    })

     //wiring up " Add Nickel" button
    $(document).on('click', '#addNickel', function(){
        alert('Nickel');
    })

    //wiring up "Make Purchase" button
    $(document).on('click', '#makePurchase', function(){
        alert('purchase attempted');
    })

    //wiring up "Change Return" button
    $(document).on('click', '#returnChangeb', function(){
        alert('purchase attempted');
    })


});
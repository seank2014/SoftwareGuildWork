/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.guessthenumber.daos;

import com.sg.guessthenumber.dto.Game;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author seanking
 */
public class GameDaoTest {
    
    public GameDaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addPlayedGame method, of class GameDao.
     */
    @Test
    public void testAddPlayedGame() {
    }

    /**
     * Test of getGameById method, of class GameDao.
     */
    @Test
    public void testGetGameById() {
    }

    /**
     * Test of getAllGames method, of class GameDao.
     */
    @Test
    public void testGetAllGames() {
    }

    /**
     * Test of updateGame method, of class GameDao.
     */
    @Test
    public void testUpdateGame() {
    }

    /**
     * Test of deleteGame method, of class GameDao.
     */
    @Test
    public void testDeleteGame() {
    }

    public class GameDaoImpl implements GameDao {

        public Game addPlayedGame(Game game) {
            return null;
        }

        public Game getGameById(int id) {
            return null;
        }

        public List<Game> getAllGames() {
            return null;
        }

        public void updateGame(Game game) {
        }

        public void deleteGame(Game game) {
        }
    }
    
}

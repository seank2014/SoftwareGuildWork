/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.guessthenumber.daos;

import com.sg.guessthenumber.dto.Round;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author seanking
 */
public class RoundDaoTest {
    
    public RoundDaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addNewRound method, of class RoundDao.
     */
    @Test
    public void testAddNewRound() {
    }

    /**
     * Test of getRoundById method, of class RoundDao.
     */
    @Test
    public void testGetRoundById() {
    }

    /**
     * Test of getAllRounds method, of class RoundDao.
     */
    @Test
    public void testGetAllRounds() {
    }

    /**
     * Test of updateRound method, of class RoundDao.
     */
    @Test
    public void testUpdateRound() {
    }

    /**
     * Test of deleteRoundById method, of class RoundDao.
     */
    @Test
    public void testDeleteRoundById() {
    }

    public class RoundDaoImpl implements RoundDao {

        public Round addNewRound(Round round) {
            return null;
        }

        public Round getRoundById(int id) {
            return null;
        }

        public List<Round> getAllRounds() {
            return null;
        }

        public void updateRound(Round round) {
        }

        public void deleteRoundById(int id) {
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.guessthenumber.controller;

import com.sg.guessthenumber.daos.GameDao;
import com.sg.guessthenumber.daos.RoundDao;
import com.sg.guessthenumber.view.GuessTheNumberView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author seanking
 */
@Component
public class RESTNumberController {
    @Autowired
    GuessTheNumberView view;
    
    @Autowired
    GameDao gameDao;
    
    @Autowired
    RoundDao roundDao;
    
    public void run(){
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.guessthenumber.dto;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author seanking
 */
public class Game {
    int Id;
    int Answer;
    boolean status;
    List<Round> rounds = new ArrayList<>();

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getAnswer() {
        return Answer;
    }

    public void setAnswer(int Answer) {
        this.Answer = Answer;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    
    public List <Round> getRounds(){
        return rounds;
    }
    
}
